
TASK_MST_SYNC
=============================

▶ Double-click TASK_MST_SYNC.exe to start the UI.

Included:
- config.json
- django_sync/
- db.sqlite3 (optional)
- TASK_MST.png
- TASK_MST.ico

You can edit config.json
without rebuilding the EXE.
